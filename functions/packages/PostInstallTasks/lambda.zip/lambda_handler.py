from helper import shared_functions
import urllib.request
import urllib.error

def get_from_s3(s3_bucket,student_cluster_name,sub_folder):
    client = boto3.client('s3')
    s3_path = os.path.join(student_cluster_name, sub_folder)
    destination = os.path.join('/tmp',student_cluster_name)
    try:
        client.head_object(Bucket=s3_bucket, Key=s3_path)
        client.download_file(s3_bucket, s3_path, destination)
    except:
        log.debug("File not found on S3! Skipping {}...".format(s3_path))

def handler(event, context):
    try:
        cf_client = boto3.client('cloudformation')
        #if event['RequestType'] == 'Delete':
        #    print("Delete request currently not supported")
        #    # Do we need to delete the Webpage that was generated?
        #    pass
        #elif event['RequestType'] == 'Update':
        #    print("Update sent, however, this is unsupported at this time.")
        #    pass
        #else:
        s3_bucket = os.getenv('S3_BUCKET')
        cluster_name = os.getenv('ClusterName')
        number_of_students = int(os.getenv('NumStudents'))
        hosted_zone_name = os.getenv('HostedZoneName')
        openshift_client_base_mirror_url = os.getenv('OPENSHIFT_MIRROR_URL')
        openshift_version = os.getenv('OPENSHIFT_VERSION')
        openshift_install_binary = os.getenv('OPENSHIFT_INSTALL_BINARY')
        file_extension = '.tar.gz'
        if sys.platform == 'darwin':
            openshift_install_os = '-mac-'
        else:
            openshift_install_os = '-linux-'
        openshift_install_package = openshift_install_binary + openshift_install_os + openshift_version + file_extension
        openshift_client_mirror_url = openshift_client_base_mirror_url + openshift_version + "/"
        download_path = '/tmp/'
        
        log.info("Cluster name: " + os.getenv('ClusterName'))
        shared_functions.install_dependencies(openshift_client_mirror_url, openshift_install_package, openshift_install_binary, download_path)
        all_ready = True
        for i in range(number_of_students):
            student_cluster_name = cluster_name + '-' + 'student' + str(i)
            fqdn_student_cluster_name = cluster_name + '-' + 'student' + str(i) + "." + hosted_zone_name
            url="https://api.t3trav02-student0.openshift.awsworkshop.io/dashboards:6443"
            try: 
                urllib.request.urlopen(url)
            except urllib.error.URLError as e:
            except: urllib.error.

                html = response.read()
            # curl fqdn_student_cluster_name:6443
            # if successful:
            # all_ready += True
            # install_dependencies
            # Download student kubeconfig
            # Execute replica scale down
            # else:
            # all_ready += false
            # Move to next student
            cmd = "./openshift-4-scale-replicas.sh {}".format(student_cluster_name)
            shared_functions.run_process(cmd)
        if False is in all_ready:
            generate_webtemplate()
        print("Complete")
    except Exception:
        logging.error('Unhandled exception', exc_info=True)